package com.aidukonis.dogimagegallery.adapter

interface GalleryImageClickListener {
    fun onClick(position: Int)
}