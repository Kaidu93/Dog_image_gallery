package com.aidukonis.dogimagegallery.adapter

data class Image (
    val imageUrl: String
)
